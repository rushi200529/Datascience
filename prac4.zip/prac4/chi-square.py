import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sb
import warnings
from scipy import stats

warnings.filterwarnings('ignore')

# load dataset and display its structure
df = sb.load_dataset('mpg')
print(df)
print("*"*50)

# explore descriptive statistics of 'horsepower' and 'model_year' columns
print(df['horsepower'].describe())
print(df['model_year'].describe())

print("*"*50)

# define bins for 'horsepower' and 'model_year' columns, and create new categorical variables
bins = [0,75,150,240]

df['horsepower_new'] = pd.cut(df['horsepower'], bins = bins,
                              labels = ['low','medium','high'])

c = df['horsepower_new']
print(c)

print("*"*50)

# define bins for 'model_year' column and create new categorical variable
ybins = [69,72,74,84]
label = ['t1','t2','t3']

df['model_year_new'] = pd.cut(df['model_year'], bins = ybins,
                              labels = label)

newyear = df['model_year_new']
print(newyear)
print("*"*50)

# create a contingency table using crosstab
df_chi = pd.crosstab(df['horsepower_new'], df['model_year_new'])
print(df_chi)
print("*"*50)

# perform chi-square test of independence
print(stats.chi2_contingency(df_chi))
print("*"*50)
