# Import libraries
import numpy as np
from scipy import stats
import matplotlib.pyplot as plt

# Generate two samples
np.random.seed(42)
sample1 = np.random.normal(loc=10, scale=2, size=30)
sample2 = np.random.normal(loc=12, scale=2, size=30)

# Perform two-sample t-test
t_statistic, p_value = stats.ttest_ind(sample1, sample2)

# Significance level
alpha = 0.05

# Print results
print("Results of the two sample t-test:")
print("T-statistic:", t_statistic)
print("P-value:", p_value)
print("Degrees of freedom:", (len(sample1) + len(sample2) - 2))


# ---------------- GRAPH 1 ----------------
# Distribution of both samples

plt.figure(figsize=(10,6))

plt.hist(sample1, alpha=0.5, label='Sample 1', color='blue')
plt.hist(sample2, alpha=0.5, label='Sample 2', color='orange')

plt.axvline(np.mean(sample1), color='blue', linestyle='dashed', linewidth=2)
plt.axvline(np.mean(sample2), color='orange', linestyle='dashed', linewidth=2)

plt.title('Distribution of Sample 1 and Sample 2')
plt.xlabel('Value')
plt.ylabel('Frequency')
plt.legend()

plt.show()


# ---------------- GRAPH 2 ----------------
# Critical region visualization

x = np.linspace(6,16,1000)
y = stats.norm.pdf(x, np.mean(sample1), np.std(sample1))

plt.figure(figsize=(8,5))

plt.plot(x, y, color='black')

# Highlight critical region
if p_value < alpha:
    plt.fill_between(x, y, where=(x < np.mean(sample1)), color='red', alpha=0.4)

# Show t-statistic
plt.text(np.mean(x), max(y)*0.9, f"T-statistic: {t_statistic:.2f}",
         ha='center', backgroundcolor='white')

plt.title("Critical Region Visualization")
plt.xlabel("Value")
plt.ylabel("Density")

plt.show()


# ---------------- CONCLUSION ----------------

if p_value < alpha:
    if np.mean(sample1) > np.mean(sample2):
        print("Conclusion: There is significant evidence to reject the null hypothesis.")
        print("Interpretation: The mean of sample1 is significantly higher than sample2.")
    else:
        print("Conclusion: There is significant evidence to reject the null hypothesis.")
        print("Interpretation: The mean of sample2 is significantly higher than that of sample1.")
else:
    print("Conclusion: Fail to reject the null hypothesis.")
    print("Interpretation: There is not enough evidence to claim a significant difference between the means.")
