#dummification
import pandas as pd
# reading dataset
iris = pd.read_csv('Iris.csv')
print(iris)

#encoding categorical data
from sklearn.preprocessing import LabelEncoder
le = LabelEncoder()
iris['code'] = le.fit_transform(iris['Species'])

#printing dataframe with encoded column
print(iris)
