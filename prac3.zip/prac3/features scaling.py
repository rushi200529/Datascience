# Import libraries
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.preprocessing import MinMaxScaler, StandardScaler

# Reading dataset
df = pd.read_csv('Wine.csv', header=None, usecols=[0,1,2], skiprows=1)

# Rename columns
df.columns = ['Class','Alcohol','Malic Acid']

# Print original dataframe
print("Original Dataframe:")
print(df)

# MinMax Scaling
scaling = MinMaxScaler()

df_scaled = scaling.fit_transform(df[['Alcohol','Malic Acid']])

df[['Alcohol','Malic Acid']] = df_scaled

# Printing dataframe after MinMax scaling
print("\nDataframe after MinMax Scaling:")
print(df)

# Standard Scaling
scaling = StandardScaler()

df_scaled = scaling.fit_transform(df[['Alcohol','Malic Acid']])

df[['Alcohol','Malic Acid']] = df_scaled

# Printing dataframe after Standard scaling
print("\nDataframe after Standard Scaling:")
print(df)
