import pandas as pd

# Specify the path to csv file
csv_file_path = "employees.csv"

# Function to read csv file
def read_csv_file(file_path):
    try:
        data_frame = pd.read_csv(file_path)
        return data_frame
    except FileNotFoundError:
        print(f"File not found at path: {file_path}")

csv_data = read_csv_file(csv_file_path)

# Print dataframe
if csv_data is not None:
    print("CSV Data:\n", csv_data)