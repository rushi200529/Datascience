import pandas as pd

def handle_outliers(column, factor=2):
    median_value = column.median()
    upper_threshold = median_value + factor * column.std()
    lower_threshold = median_value - factor * column.std()
    return column.apply(lambda x: median_value if x > upper_threshold or x < lower_threshold else x)

# read data from csv file
csv_file_path = "sales.csv"
df_csv = pd.read_csv(csv_file_path)

# read data from json file
json_file_path = "sales.json"
df_json = pd.read_json(json_file_path)

# display first few rows
print("handling outliers")
print("CSV Data:")
print(df_csv.head())
print("\nJSON Data:")
print(df_json.head())

# handling missing values
# drop rows with missing values
df_csv_cleaned = df_csv.dropna()

# fill missing values with a specific value (e.g., 0)
df_json_filled = df_json.fillna(0)

# handling outliers
# assume 'sales' is the column with outliers
# replace outliers with the median using the handle_outliers function
df_csv['sales'] = handle_outliers(df_csv['sales'])

# manipulate and transform data

# filtering
filtered_data = df_csv[df_csv['sales'] > 10]

# sorting
sorted_data = df_csv.sort_values(by="sales", ascending=False)

# grouping and calculating mean for numeric columns
numeric_columns = ['sales', 'cost', 'profit']
grouped_data = df_csv.groupby('category')[numeric_columns].mean()

print("\nCSV Data (cleaned/handle missing values):")
print(df_csv_cleaned.head())

print("\nJSON Data (filled):")
print(df_json_filled.head())

print("\nFiltered Data:")
print(filtered_data.head())

print("\nSorted Data:")
print(sorted_data.head())

print("\nGrouped Data:")
print(grouped_data.head())
