import json

# specify path of json file
json_file_path = "employee.json"

# function to read json file
def read_json_file(file_path):
    with open(file_path, 'r') as json_file:
        json_data = json.load(json_file)
        return json_data

# call function
try:
    json_data = read_json_file(json_file_path)
    print("JSON Data:", json_data)
    print(json.dumps(json_data, indent=4))

except FileNotFoundError:
    print(f"File not found at path : {json_file_path}")

except json.JSONDecodeError:
    print(f"Error decoding JSON file at path : {json_file_path}")
