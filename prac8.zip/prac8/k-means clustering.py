# Import libraries
import numpy as np
import pandas as pd

# Read the dataset and display its first few rows
data = pd.read_csv('Wholesale.csv')
print(data.head())
print("**"*25)

# Read the dataset again to ensure original columns are present
data = pd.read_csv('Wholesale.csv')

# Define categorical and continuous features
categorical_features = ['Channel', 'Region']
continuous_features = ['Fresh', 'Milk', 'Grocery', 'Frozen', 'Detergents_Paper', 'Delicassen']

data[continuous_features].describe()

# Convert categorical features into dummy variables
for col in categorical_features:
    dummies = pd.get_dummies(data[col], prefix=col)
    data = pd.concat([data, dummies], axis=1)
    data.drop(col, axis=1, inplace=True)

print(data.head())

# Scale the data using MinMaxScaler
from sklearn.preprocessing import MinMaxScaler

scaler = MinMaxScaler()
scaler.fit(data)

data_transformed = scaler.transform(data)

# Determine the optimal number of clusters using the elbow method
sum_of_squared_distances = []

from sklearn.cluster import KMeans

K = range(1, 15)

for k in K:
    km = KMeans(n_clusters=k)
    km = km.fit(data_transformed)
    sum_of_squared_distances.append(km.inertia_)

import matplotlib.pyplot as plt

# Plot the elbow curve to find the optimal K
plt.plot(K, sum_of_squared_distances, 'bx-')
plt.xlabel('k')
plt.ylabel('Sum of squared distances')
plt.title('Elbow Method For Optimal k')
plt.show()
