# Import libraries
import pandas as pd
import scipy.stats as stats
from statsmodels.stats.multicomp import pairwise_tukeyhsd

# Defining data for groups and combining them into a single list
g1 = [23,25,29,34,30]
g2 = [19,20,26,24,25]
g3 = [15,18,20,21,17]
g4 = [28,24,26,30,29]

all_data = g1 + g2 + g3 + g4

# Defining group labels
group_labels = (['g1'] * len(g1) +
                ['g2'] * len(g2) +
                ['g3'] * len(g3) +
                ['g4'] * len(g4))

# Perform one-way ANOVA
f_statistic, p_value = stats.f_oneway(g1, g2, g3, g4)

print("One-way ANOVA Results:")
print("F-statistic:", f_statistic)
print("P-value:", p_value)

# Perform Tukey-Kramer post-hoc test
tukey_results = pairwise_tukeyhsd(all_data, group_labels)

print("\nTukey-Kramer Post-hoc Test Results:")
print(tukey_results)
