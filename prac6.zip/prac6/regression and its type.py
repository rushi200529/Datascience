# Ignore warnings
import warnings
warnings.filterwarnings("ignore")

# Import libraries
import numpy as np
import pandas as pd
from sklearn.datasets import fetch_california_housing, load_diabetes
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score


# Load dataset (try california housing, if fails use diabetes dataset)
try:
    housing_data = fetch_california_housing()
    housing_df = pd.DataFrame(data=housing_data.data,
                              columns=housing_data.feature_names)
    housing_df['PRICE'] = housing_data.target

except:
    print("Using Diabetes dataset instead.")
    
    housing_data = load_diabetes()
    housing_df = pd.DataFrame(data=housing_data.data,
                              columns=housing_data.feature_names)
    housing_df['PRICE'] = housing_data.target


# Show first 5 entries
print(housing_df.head())


# Select feature and target
X = housing_df[[housing_df.columns[0]]]   # first column as feature
y = housing_df['PRICE']


# Split dataset
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42)


# Train model
model = LinearRegression()
model.fit(X_train, y_train)


# Predict
y_pred = model.predict(X_test)


# Evaluation
mse = mean_squared_error(y_test, y_pred)
r2 = r2_score(y_test, y_pred)

print("\nSimple Linear Regression Results")
print("Mean Squared Error:", mse)
print("R-squared:", r2)
print("Intercept:", model.intercept_)
print("Coefficient:", model.coef_)


# Select all features except PRICE
X = housing_df.drop('PRICE', axis=1)
y = housing_df['PRICE']


# Split dataset
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42)


# Train model
model = LinearRegression()
model.fit(X_train, y_train)


# Predict
y_pred = model.predict(X_test)


# Evaluation
mse = mean_squared_error(y_test, y_pred)
r2 = r2_score(y_test, y_pred)

print("\nMultiple Linear Regression Results")
print("Mean Squared Error:", mse)
print("R-squared:", r2)
print("Intercept:", model.intercept_)
print("Coefficients:", model.coef_)
